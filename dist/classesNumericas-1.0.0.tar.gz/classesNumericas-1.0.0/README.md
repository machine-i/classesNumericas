# cafeComVogal

**classesNumericas** é um pacote, cujo intuito é obter as classes numéricas de número inteiros.
**classes_numericas()**. Essa é responsável por encontrar tais classes.

# Função

* `classes_numericas(n: int) -> str` - Recebe um inteiro e
retorna uma string. O retorno seria algo semelhante a "3 centenas, 2 dezenas e 1 unidade", isso se o inteiro passado como parâmetro for "321".